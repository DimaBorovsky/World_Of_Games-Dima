name = input("What's your name:")
game = [1,2,3]
difficulty = [1,2,3,4,5]

def welcome_user():
  print(f"Hello {name}, and welcome to the World of games !")


def load_game():
    print("1-Memory Game\n2-Guess Game\n3-Currency roulette")
    game_choice = input(f"Please Choose a  game {game}:")
    if game_choice == str(1):
        print("you Chose Memory Game")
    elif game_choice == str(2):
        print("you Chose guess game")
    else:
        print("You choose currency roulette")

    difficulty_of_game = int(input(f"Please choose a difficulty level{difficulty}: "))
    if difficulty_of_game == 1:
        print("you choose level 1")
    elif difficulty_of_game == 2:
        print("you choose level 2")
    elif difficulty_of_game == 3:
        print("you choose level 3")
    elif difficulty_of_game == 4:
        print("you choose level 4")
    elif difficulty_of_game == 5:
        print("You choose leve 5")
    else:
        print("Invalid Choice Pleasez chhose from the followingg list 1,2,3,4 & 5")



