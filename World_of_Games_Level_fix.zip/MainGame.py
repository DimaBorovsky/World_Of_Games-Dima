from Live import welcome_user, load_game

print(welcome_user())
load_game()

