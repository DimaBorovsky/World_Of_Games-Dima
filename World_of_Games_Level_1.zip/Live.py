name = input("What's your name:")
game = [1,2,3]
difficulty = [1,2,3,4,5]

def welcome_user():
  print(f"Hello {name}, and welcome to the World of games !")


def load_game():
    print(
        "Please choose a game"
        "1-Memory Game- a sequence of numbers will appear for 1 second and you have to guess it back"
        "2- Guess game-Guess a number and see if you chose like the computer "
        "3-Currency Roullete-try and guess the value of a random amount of USD in ILS")
    input(f"Please choose a {game} ")
    if game == 1:
      print("you chose Memory game")
    elif game == 2:
        print("you choose Guess game ")
    else:
        print("you chose Currency roullette")
        input(f"Please choose a {difficulty}")



