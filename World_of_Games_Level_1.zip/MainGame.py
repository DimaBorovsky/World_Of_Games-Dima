from Live import load_game, welcome_user

print(welcome_user)
load_game()