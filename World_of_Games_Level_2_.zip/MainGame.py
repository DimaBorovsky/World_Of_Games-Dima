from Live import welcome_user, load_game
from  Guess_Game import play
from Memory_Game import play1
from CurrencyRouletteGame import play3


welcome_user()
load_game()
play()
play1()
play3()